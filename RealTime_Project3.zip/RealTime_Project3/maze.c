#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <pthread.h>
#include <stdatomic.h>
#include "maze.h"

// -------------------------------------------------
// Global variables (real definitions)
// -------------------------------------------------
int MAZE_W = 0;                 // Maze width
int MAZE_H = 0;                 // Maze height
Cell **maze = NULL;             // 2D grid of maze cells
pthread_mutex_t **maze_mutex = NULL; // 2D grid of mutexes (one per cell)
int initial_bananas = 0;        // Total bananas at the start
atomic_int remaining_bananas;   // Atomic counter of remaining bananas

// -------------------------------------------------
// Create the maze and fill it with obstacles + bananas
// -------------------------------------------------
void maze_init(int W, int H, int obstacles_percent, int max_bananas)
{
    MAZE_W = W;
    MAZE_H = H;

    // Allocate rows for cells and mutexes
    maze = calloc(MAZE_H, sizeof(Cell *));
    maze_mutex = calloc(MAZE_H, sizeof(pthread_mutex_t *));
    if (!maze || !maze_mutex) {
        fprintf(stderr, "Error: cannot allocate maze rows\n");
        exit(1);
    }

    for (int y = 0; y < MAZE_H; y++) {
        // Allocate each row
        maze[y] = calloc(MAZE_W, sizeof(Cell));
        maze_mutex[y] = calloc(MAZE_W, sizeof(pthread_mutex_t));

        if (!maze[y] || !maze_mutex[y]) {
            fprintf(stderr, "Error: cannot allocate maze row %d\n", y);
            exit(1);
        }

        for (int x = 0; x < MAZE_W; x++) {
            // Initialize the mutex for this cell
            pthread_mutex_init(&maze_mutex[y][x], NULL);

            // Random decision: obstacle or free
            int r = rand() % 100;
            if (r < obstacles_percent) {
                maze[y][x].obstacle = 1;   // Blocked cell
                atomic_init(&maze[y][x].bananas, 0);    // No bananas on obstacles
            } else {
                maze[y][x].obstacle = 0;   // Free cell
                // Random bananas between 0 and max_bananas
                atomic_init(&maze[y][x].bananas, rand() % (max_bananas + 1));
            }
            maze[y][x].occupant = -1;  // No occupant
        }
    }

    // Count all initial bananas
    atomic_init(&remaining_bananas, 0);
    for (int y = 0; y < MAZE_H; y++) {
        for (int x = 0; x < MAZE_W; x++) {
            atomic_fetch_add(&remaining_bananas, atomic_load(&maze[y][x].bananas));
        }
    }

    initial_bananas = atomic_load(&remaining_bananas);
    printf("[DEBUG] Maze %dx%d initialized\n", MAZE_W, MAZE_H);
    printf("[DEBUG] Total bananas initially = %d\n", initial_bananas);
}

// -------------------------------------------------
// Free memory and destroy all mutexes
// -------------------------------------------------
void maze_destroy(void)
{
    if (!maze || !maze_mutex)
        return;

    for (int y = 0; y < MAZE_H; y++) {
        // Destroy all mutexes in this row
        for (int x = 0; x < MAZE_W; x++) {
            pthread_mutex_destroy(&maze_mutex[y][x]);
        }

        // Free row arrays
        free(maze[y]);
        free(maze_mutex[y]);
    }

    // Free top-level pointers
    free(maze);
    free(maze_mutex);

    maze = NULL;
    maze_mutex = NULL;
    MAZE_W = 0;
    MAZE_H = 0;
    initial_bananas = 0;
}

// -------------------------------------------------
// Keep a coordinate inside the maze boundaries
// -------------------------------------------------
void maze_clamp(int *x, int *y)
{
    if (*x < 0)         *x = 0;
    if (*y < 0)         *y = 0;
    if (*x >= MAZE_W)   *x = MAZE_W - 1;
    if (*y >= MAZE_H)   *y = MAZE_H - 1;
}

// -------------------------------------------------
// Thread-safe banana taking operation
// -------------------------------------------------
int maze_take_bananas(int x, int y, int max_take)
{
    int taken = 0;
    // Caller MUST hold maze_mutex[y][x] before calling this function

    int cur = atomic_load(&maze[y][x].bananas);
    if (cur > 0) {
        taken = (cur >= max_take) ? max_take : cur;
        atomic_fetch_sub(&maze[y][x].bananas, taken);
        atomic_fetch_sub(&remaining_bananas, taken);
    }


    return taken;
}

// -------------------------------------------------
// Lock a maze cell (used when an ape occupies a cell)
// -------------------------------------------------
void maze_lock(int x, int y)
{
    pthread_mutex_lock(&maze_mutex[y][x]);
}

// -------------------------------------------------
// Unlock a maze cell
// -------------------------------------------------
void maze_unlock(int x, int y)
{
    pthread_mutex_unlock(&maze_mutex[y][x]);
}


// -------------------------------------------------
// Count all bananas left in the maze
// -------------------------------------------------
// int count_remaining_bananas(void)
// {
//     int total = 0;

//     for (int y = 0; y < MAZE_H; y++) {
//         for (int x = 0; x < MAZE_W; x++) {
//             total += maze[y][x].bananas;
//         }
//     }

//     return total;
// }
int count_remaining_bananas(void)
{
    return atomic_load(&remaining_bananas);
}

// -------------------------------------------------
// Find nearest cell that still has bananas
// Returns 1 if found, 0 if no bananas exist
// -------------------------------------------------
int maze_find_nearest_banana(int sx, int sy, int *bx, int *by)
{
    int best_dist = -1;
    int found = 0;

    for (int y = 0; y < MAZE_H; y++) {
        for (int x = 0; x < MAZE_W; x++) {

            // Skip obstacles
            if (maze[y][x].obstacle)
                continue;

            // Skip empty cells
            if (atomic_load(&maze[y][x].bananas) <= 0)
                continue;

            // sx,sy Current position of the female ape
            // x,y Position of a cell with bananas
            // dx,dy Distance components
                int dx = x - sx;
            if (dx < 0) dx = -dx;
            int dy = y - sy;
            if (dy < 0) dy = -dy;
            int dist = dx + dy;   // Manhattan distance

            //bx,by banana position found
            if (!found || dist < best_dist) {
                best_dist = dist;
                *bx = x;
                *by = y;
                found = 1;
            }
        }
    }

    return found;
}

int maze_cell_id(int x, int y)
{
    return y * MAZE_W + x;
}

