#ifndef BABY_H
#define BABY_H

void *baby_thread(void *arg);

#endif
