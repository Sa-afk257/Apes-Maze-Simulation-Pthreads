#include "render.h"
#include "shared_state.h"
#include "sync.h"
#include "maze.h"
#include "female.h"

#include <GL/glut.h>
#include <GL/glu.h>

#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <math.h>

// ---------- Snapshot struct (read-only copy for drawing) ----------
typedef struct {
    int withdrawn_count;

    int num_males;
    int energy[256];
    int withdrawn[256];
    int basket[256];

    int remaining_bananas;

    // ===== NEW: babies per male =====
    int baby_count[256];
    int baby_eaten_sum[256];

    // (optional) top baby info
    int top_baby_id;
    int top_baby_dad;
    int top_baby_eaten;

} RenderSnapshot;

RenderSnapshot S;

// window size
int g_win_w = 1400;
int g_win_h = 900;

// split ratio: left panel for maze
float g_split = 0.55f;

// ---------- helpers (NO static) ----------
void draw_text(float x, float y, const char *txt)
{
    glRasterPos2f(x, y);
    for (const char *p = txt; *p; ++p)
        glutBitmapCharacter(GLUT_BITMAP_8_BY_13, *p);
}

void rect(float x0, float y0, float x1, float y1)
{
    glBegin(GL_QUADS);
    glVertex2f(x0, y0);
    glVertex2f(x1, y0);
    glVertex2f(x1, y1);
    glVertex2f(x0, y1);
    glEnd();
}

void circle(float cx, float cy, float r, int seg)
{
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx, cy);
    for (int i = 0; i <= seg; i++) {
        float a = (float)i * 6.2831853f / (float)seg;
        glVertex2f(cx + r * cosf(a), cy + r * sinf(a));
    }
    glEnd();
}

void mkdir_if_missing(const char *dir)
{
    struct stat st;
    if (stat(dir, &st) == 0 && S_ISDIR(st.st_mode)) return;
    mkdir(dir, 0755);
}

// ======================================================
// MUST match render.h:
// void save_screenshot_ppm(const char *filename, int w, int h);
// ======================================================
void save_screenshot_ppm(const char *filename, int w, int h)
{
    unsigned char *pixels = (unsigned char*)malloc((size_t)w * (size_t)h * 3);
    if (!pixels) return;

    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, w, h, GL_RGB, GL_UNSIGNED_BYTE, pixels);

    FILE *f = fopen(filename, "wb");
    if (!f) { free(pixels); return; }

    fprintf(f, "P6\n%d %d\n255\n", w, h);

    // flip vertically
    for (int y = h - 1; y >= 0; y--) {
        fwrite(pixels + (size_t)y * (size_t)w * 3, 1, (size_t)w * 3, f);
    }

    fclose(f);
    free(pixels);
}

void take_snapshot(void)
{
    S.withdrawn_count   = atomic_load(&G.withdrawn_families_count);
    S.remaining_bananas = count_remaining_bananas();

    S.num_males = G.cfg.num_males;
    if (S.num_males > 256) S.num_males = 256;

    for (int i = 0; i < S.num_males; i++) {
        S.energy[i]    = G.males[i].energy;
        S.withdrawn[i] = G.males[i].withdrawn;
        S.basket[i]    = basket_get(i);

        // NEW init
        S.baby_count[i]     = 0;
        S.baby_eaten_sum[i] = 0;
    }

    // NEW: aggregate babies per dad
    int best = -1;
    int maxEat = -1;

    // Assumes these exist in your project (they do in your shared_state.c):
    //   G.total_babies
    //   G.babies[i].dad_id
    //   G.babies[i].eaten_bananas
    for (int i = 0; i < G.total_babies; i++) {
        int dad = G.babies[i].dad_id;
        int eat = G.babies[i].eaten_bananas;

        if (dad >= 0 && dad < S.num_males) {
            S.baby_count[dad] += 1;
            S.baby_eaten_sum[dad] += eat;
        }

        if (eat > maxEat) {
            maxEat = eat;
            best = i;
        }
    }

    S.top_baby_id = best;
    if (best != -1) {
        S.top_baby_dad   = G.babies[best].dad_id;
        S.top_baby_eaten = G.babies[best].eaten_bananas;
    } else {
        S.top_baby_dad   = -1;
        S.top_baby_eaten = 0;
    }
}

void draw_maze_panel(float L, float R, float B, float T)
{
    glColor3f(0.97f, 0.97f, 0.97f);
    rect(L, B, R, T);

    if (MAZE_W <= 0 || MAZE_H <= 0 || !maze) {
        glColor3f(0,0,0);
        draw_text(L + 0.02f, T - 0.06f, "Maze not initialized.");
        return;
    }

    float w = (R - L);
    float h = (T - B);
    float cellW = w / (float)MAZE_W;
    float cellH = h / (float)MAZE_H;

    for (int y = 0; y < MAZE_H; y++) {
        for (int x = 0; x < MAZE_W; x++) {

            float x0 = L + x * cellW;
            float y0 = B + y * cellH;
            float x1 = x0 + cellW;
            float y1 = y0 + cellH;

            if (maze[y][x].obstacle) {
                glColor3f(0.15f, 0.15f, 0.15f);
                rect(x0, y0, x1, y1);
                continue;
            }

            int b = maze[y][x].bananas;
            float heat = (float)b / 8.0f;   // normalize
            clamp01(&heat);                 // uses clamp01(float *v)

            glColor3f(1.0f, 1.0f - 0.5f*heat, 1.0f - 1.0f*heat);
            rect(x0, y0, x1, y1);
        }
    }

    // grid
    glColor3f(0.85f, 0.85f, 0.85f);
    glBegin(GL_LINES);
    for (int x = 0; x <= MAZE_W; x++) {
        float X = L + x * cellW;
        glVertex2f(X, B);
        glVertex2f(X, T);
    }
    for (int y = 0; y <= MAZE_H; y++) {
        float Y = B + y * cellH;
        glVertex2f(L, Y);
        glVertex2f(R, Y);
    }
    glEnd();

    // females
    if (females) {
        for (int i = 0; i < G.cfg.num_females; i++) {
            FemaleApe *f = &females[i];

            int fx, fy, resting;

            pthread_mutex_lock(&f->pos_mutex);
            fx = f->x;
            fy = f->y;
            resting = f->resting;
            pthread_mutex_unlock(&f->pos_mutex);

            float cx = L + (fx + 0.5f) * cellW;
            float cy = B + (fy + 0.5f) * cellH;
            float rr = 0.35f * ((cellW < cellH) ? cellW : cellH);

            if (resting) glColor3f(0.2f, 0.2f, 1.0f);
            else         glColor3f(0.1f, 0.6f, 0.1f);

            circle(cx, cy, rr, 16);
        }
    }

    glColor3f(0,0,0);
    draw_text(L + 0.02f, T - 0.05f, "Maze (obstacles + bananas heat + females)");
}

void draw_stats_panel(float L, float R, float B, float T)
{
    glColor3f(0.98f, 0.98f, 0.99f);
    rect(L, B, R, T);

    glColor3f(0,0,0);

    char line[256];

    // ---------------- Header ----------------
    snprintf(line, sizeof(line), "Remaining bananas: %d", S.remaining_bananas);
    draw_text(L + 0.02f, T - 0.06f, line);

    snprintf(line, sizeof(line), "Withdrawn families: %d", S.withdrawn_count);
    draw_text(L + 0.02f, T - 0.11f, line);

    // ---------------- Female stats ----------------
    int totalF = G.cfg.num_females;
    int showF  = totalF;
    if (showF > 6) showF = 6;   // show up to 6 females

    float y = T - 0.16f;
    float lineH = 0.045f;

    if (showF > 0 && females) {
        for (int fi = 0; fi < showF; fi++) {
            int e, b, rest, id;

            pthread_mutex_lock(&females[fi].stats_mutex);
            e    = females[fi].energy;
            b    = females[fi].bananas;
            rest = females[fi].resting;
            id   = females[fi].id;
            pthread_mutex_unlock(&females[fi].stats_mutex);

            char buf[160];
            snprintf(buf, sizeof(buf),
                     "Female %d: E=%d  bananas=%d  %s",
                     id, e, b, rest ? "(resting)" : "");

            draw_text(L + 0.02f, y, buf);
            y -= lineH;
        }

        if (totalF > showF) {
            char more[128];
            snprintf(more, sizeof(more), "... %d more females not shown", totalF - showF);
            draw_text(L + 0.02f, y, more);
            y -= lineH;
        }
    }

    // leave a small gap before males section
    y -= 0.03f;

    // ---------------- Male label ----------------
    draw_text(L + 0.02f, y, "Per-male: Energy bar | Basket bar | Babies (icons) | W=withdrawn");
    y -= 0.06f;

    // ---------------- Male bars ----------------
    int n = S.num_males;
    if (n <= 0) {
        glColor3f(0,0,0);
        draw_text(L + 0.02f, B + 0.02f, "Keys: F fullscreen | P screenshot | Q/ESC quit");
        return;
    }

    float rowH = 0.065f; // a bit bigger because we will add babies line

    for (int mi = 0; mi < n; mi++) {
        if (y < B + 0.08f) break;

        snprintf(line, sizeof(line), "Male %d", mi);
        glColor3f(0,0,0);
        draw_text(L + 0.02f, y + 0.016f, line);

        // ---- energy bar ----
        float eNorm = (float)S.energy[mi] / 100.0f;
        clamp01(&eNorm);

        float bx0 = L + 0.18f;
        float bx1 = L + 0.55f;
        float by0 = y;
        float by1 = y + 0.03f;

        glColor3f(0.85f, 0.85f, 0.85f);
        rect(bx0, by0, bx1, by1);

        glColor3f(0.2f, 0.6f, 0.2f);
        rect(bx0, by0, bx0 + (bx1 - bx0) * eNorm, by1);

        // ---- basket bar ----
        float bNorm = (float)S.basket[mi] / 50.0f;
        clamp01(&bNorm);

        float cx0 = L + 0.58f;
        float cx1 = R - 0.08f;

        glColor3f(0.85f, 0.85f, 0.85f);
        rect(cx0, by0, cx1, by1);

        glColor3f(0.9f, 0.6f, 0.1f);
        rect(cx0, by0, cx0 + (cx1 - cx0) * bNorm, by1);

        if (S.withdrawn[mi]) {
            glColor3f(0.8f, 0.1f, 0.1f);
            draw_text(R - 0.07f, y + 0.016f, "W");
        }

        // ===== NEW: Babies info + icons =====
        {
            int bc = S.baby_count[mi];
            int be = S.baby_eaten_sum[mi];

            char bb[128];
            snprintf(bb, sizeof(bb), "Babies=%d  Eaten=%d", bc, be);
            glColor3f(0,0,0);
            draw_text(L + 0.18f, y - 0.020f, bb);

            // icons near basket bar
            int icons = bc;
            if (icons > 6) icons = 6;

            float iconY = y - 0.010f;
            float iconR = 0.010f;
            float iconX0 = cx0 + 0.02f;

            if (S.withdrawn[mi]) glColor3f(0.70f, 0.70f, 0.70f);
            else                 glColor3f(0.90f, 0.45f, 0.15f);

            for (int k = 0; k < icons; k++) {
                circle(iconX0 + k * 0.030f, iconY, iconR, 12);
            }
        }

        y -= rowH;
    }

    // ===== NEW: Top baby eater (optional) =====
    if (S.top_baby_id != -1) {
        char tb[180];
        snprintf(tb, sizeof(tb), "Top baby: #%d (dad=%d) eaten=%d",
                 S.top_baby_id, S.top_baby_dad, S.top_baby_eaten);
        glColor3f(0,0,0);
        draw_text(L + 0.02f, B + 0.05f, tb);
    }

    glColor3f(0,0,0);
    draw_text(L + 0.02f, B + 0.02f, "Keys: F fullscreen | P screenshot | Q/ESC quit");
}

// ---------- GLUT callbacks (NO static) ----------
void reshape(int w, int h)
{
    if (w <= 0) w = 1;
    if (h <= 0) h = 1;
    g_win_w = w;
    g_win_h = h;

    glViewport(0, 0, w, h);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1, 1, -1, 1);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void keyboard(unsigned char key, int x, int y)
{
    (void)x; (void)y;

    if (key == 27 || key == 'q' || key == 'Q') {
        atomic_store(&G.simulation_running, 0);
        exit(0);
    }

    if (key == 'f' || key == 'F') {
        glutFullScreen();
    }

    if (key == 'p' || key == 'P') {
        mkdir_if_missing("figures");
        static int shot = 0;
        char path[256];
        snprintf(path, sizeof(path), "figures/shot_%04d.ppm", shot++);
        save_screenshot_ppm(path, g_win_w, g_win_h);
        fprintf(stderr, "[GL] Saved %s\n", path);
    }
}

void display(void)
{
    glClearColor(1, 1, 1, 1);
    glClear(GL_COLOR_BUFFER_BIT);

    take_snapshot();

    float L = -1.f, R = 1.f, B = -1.f, T = 1.f;
    float split = -1.f + 2.f * g_split;

    glColor3f(0.7f, 0.7f, 0.7f);
    glBegin(GL_LINES);
    glVertex2f(split, B);
    glVertex2f(split, T);
    glEnd();

    draw_maze_panel(L, split, B, T);
    draw_stats_panel(split, R, B, T);

    glutSwapBuffers();
}

void timer_cb(int v)
{
    (void)v;

    if (!atomic_load(&G.simulation_running)) {
        exit(0);
    }

    glutPostRedisplay();
    glutTimerFunc(G.cfg.render_ms, timer_cb, 0);
}

void *render_thread(void *arg)
{
    (void)arg;

    int argc = 1;
    char *argv0 = (char*)"sim";
    char *argv[] = { argv0, NULL };

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(g_win_w, g_win_h);
    glutCreateWindow("Apes Maze Simulation (OpenGL)");

    glDisable(GL_DEPTH_TEST);

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutTimerFunc(G.cfg.render_ms, timer_cb, 0);

    glutMainLoop();
    return NULL;
}

// render.h declares: void clamp01(float *v);
// We must define it somewhere to satisfy the linker.
void clamp01(float *v)
{
    if (!v) return;
    if (*v < 0.0f) *v = 0.0f;
    else if (*v > 1.0f) *v = 1.0f;
}
