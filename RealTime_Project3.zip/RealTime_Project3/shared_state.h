#ifndef SHARED_STATE_H
#define SHARED_STATE_H

#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>

#include "config.h"   // <-- IMPORTANT: single source of truth for Config

// -------------------- Fight Event --------------------
typedef struct {
    int active;
    int maleA;
    int maleB;
    uint64_t until_ms;               // event expiry time (monotonic ms)
} FightEvent;

// -------------------- Male / Baby --------------------
typedef struct {
    int id;
    int energy;
    int withdrawn;

    int basket_bananas;
    pthread_mutex_t basket_mutex;
} Male;

typedef struct {
    int id;
    int dad_id;
    int eaten_bananas;
} Baby;

// -------------------- Global Shared State --------------------
typedef struct {
    Config cfg;                      // <-- from config.h

    Male *males;
    Baby *babies;

    int total_babies;

    // Counters (shared)
    atomic_int withdrawn_families_count;
    atomic_int simulation_running;

    // For "someone reached threshold" quick checks
    atomic_int any_family_reached_basket_threshold;
    atomic_int any_baby_reached_eat_threshold;

    // Fight event
    FightEvent fight_event;
    pthread_mutex_t fight_event_mutex;

    // Stop coordination
    pthread_mutex_t stop_mutex;
    pthread_cond_t  stop_cv;

    // Start time
    uint64_t start_ms;

    pthread_mutex_t *basket_gate;   // size = num_males
    int *exit_x;                    // size = num_males
    int *exit_y;                    // size = num_males

} SharedState;

extern SharedState G;

// -------------------- Helpers --------------------
uint64_t now_ms(void);
void ms_sleep(int ms);

// Thread-safe random helpers
int rand_int(int lo, int hi);        // inclusive
double rand_double_0_1(void);

// Init / cleanup
int shared_init(const Config *cfg);
void shared_cleanup(void);

// Basket helpers (locks internally)
void basket_add(int male_id, int amount);
int  basket_take_all(int male_id);
int  basket_get(int male_id);

// Fight event helpers
void fight_event_set(int a, int b, int duration_ms);
int  fight_event_get(FightEvent *out);

// Stop helpers
void request_stop(void); // sets simulation_running=0 and broadcasts




#endif
