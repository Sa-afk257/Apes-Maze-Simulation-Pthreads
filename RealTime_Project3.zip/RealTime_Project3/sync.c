#include "sync.h"
#include <pthread.h>
#include <stdatomic.h>

/* ---- TIME LIMIT flag ---- */
atomic_int time_up = 0;
int TIME_LIMIT;

/* ---- Global simulation flag ---- */
atomic_int simulation_running = 1;


/* ---- Fight mutex (female-female fights) ---- */
pthread_mutex_t fight_mutex = PTHREAD_MUTEX_INITIALIZER;

/* ---- Withdrawn families counter ---- */
int withdrawn_count = 0;
pthread_mutex_t withdrawn_mutex = PTHREAD_MUTEX_INITIALIZER;

void increment_withdrawn(void)
{
    pthread_mutex_lock(&withdrawn_mutex);
    withdrawn_count++;
    pthread_mutex_unlock(&withdrawn_mutex);
}

/* ---- User-defined parameters (filled by config.c) ---- */
int REST_THRESHOLD;
int REST_TIME;
int MAX_ENERGY;
int MOVE_COST;
int COLLECT_COST;
int FIGHT_WIN_COST;
int FIGHT_LOSE_COST;
int EXIT_LIMIT;
int COLLECT_LIMIT;
int MALE_MIN_ENERGY;
int NUM_FEMALES;

/* male_energy[] is defined in basket.c but visible here */
