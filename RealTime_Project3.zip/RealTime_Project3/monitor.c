#include "monitor.h"
#include "shared_state.h"
#include <stdio.h>

static int elapsed_seconds(void) {
    uint64_t e = now_ms() - G.start_ms;
    return (int)(e / 1000ULL);
}

void *monitor_thread(void *arg) {
    (void)arg;

    while (atomic_load(&G.simulation_running)) {
        int w = atomic_load(&G.withdrawn_families_count);
        if (w >= G.cfg.withdrawn_families_threshold) {
            printf("[MONITOR] Stop: withdrawn families reached %d\n", w);
            request_stop();
            break;
        }

        if (atomic_load(&G.any_family_reached_basket_threshold)) {
            printf("[MONITOR] Stop: a family reached basket threshold\n");
            request_stop();
            break;
        }

        if (atomic_load(&G.any_baby_reached_eat_threshold)) {
            printf("[MONITOR] Stop: a baby reached eating threshold\n");
            request_stop();
            break;
        }

        if (elapsed_seconds() >= G.cfg.time_limit_sec) {
            printf("[MONITOR] Stop: time limit reached (%d sec)\n", G.cfg.time_limit_sec);
            request_stop();
            break;
        }

        ms_sleep(G.cfg.monitor_check_ms);
    }

    return NULL;
}
