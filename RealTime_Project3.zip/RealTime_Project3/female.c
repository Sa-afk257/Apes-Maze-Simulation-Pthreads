#include "female.h"
#include "maze.h"
#include "male.h"
#include "sync.h"
#include "shared_state.h"

#include <unistd.h>
#include <stdatomic.h>


FemaleApe *females = NULL;

//Thread Main Loop
void *female_thread(void *arg)
{
    FemaleApe *f = (FemaleApe *)arg;

    /* Each female ape runs here as an independent POSIX thread */
    while (atomic_load(&G.simulation_running) && !f->withdrawn && !atomic_load(&G.any_family_reached_basket_threshold))

    {
        int withdrawn_now, energy_now;

        pthread_mutex_lock(&f->stats_mutex);
        withdrawn_now = f->withdrawn;
        energy_now = f->energy;
        pthread_mutex_unlock(&f->stats_mutex);

        if (withdrawn_now) break;

        /* If energy is low, she must rest */
        if (energy_now < REST_THRESHOLD)
        {
            female_rest(f);
        }
        else
        {
            /* Otherwise she moves inside the maze and collects bananas */
            female_move(f);
        }
	
	

	    /* Slow the simulation to make it realistic and visible */
        sleep(1);
    }

    /* Thread ends when withdrawn or simulation stops */
    /* Thread ends cleanly here */
    pthread_exit(NULL);
}

void female_init(FemaleApe *f, int id)
{
    f->id = id;
    f->energy = MAX_ENERGY;
    f->bananas = 0;
    f->withdrawn = 0;
    f->resting = 0;
    f->family_id = id % G.cfg.num_males;
    f->going_to_exit = 0;

    

    // Clustered start zone near (1,1)
    f->x = 1 + (id % 3);
    f->y = 1 + (id / 3);

    // Safety clamp (in case of small mazes)
    maze_clamp(&f->x, &f->y);

    // If that cell is obstacle, slide to nearest free one
    while (maze[f->y][f->x].obstacle) {
        f->x++;
        maze_clamp(&f->x, &f->y);
    }

    /* REGISTER OCCUPANCY */
    maze_lock(f->x, f->y);
    maze[f->y][f->x].occupant = f->id;
    maze_unlock(f->x, f->y);
    pthread_mutex_init(&f->stats_mutex, NULL);

}

void female_rest(FemaleApe *f)
{
    pthread_mutex_lock(&f->stats_mutex);
    /* Mark this female as resting */
    f->resting = 1;
    pthread_mutex_unlock(&f->stats_mutex);

    /* She sleeps to regain energy */
    sleep(REST_TIME);

    pthread_mutex_lock(&f->stats_mutex);
    /* Restore her energy to full */
    f->energy = MAX_ENERGY;

    /* She becomes active again */
    f->resting = 0;
    pthread_mutex_unlock(&f->stats_mutex);
}

void female_move(FemaleApe *f)
{
    int nextx, nexty;
    // int bananax = f->x, bananay = f->y;   // safe defaults

    // -----------------------------
    // 1) Choose target step (no locks)
    // -----------------------------
    // if (maze_find_nearest_banana(f->x, f->y, &bananax, &bananay))
    // {
    //     if (bananax > f->x) nextx = f->x + 1;
    //     else if (bananax < f->x) nextx = f->x - 1;
    //     else nextx = f->x;

    //     if (bananay > f->y) nexty = f->y + 1;
    //     else if (bananay < f->y) nexty = f->y - 1;
    //     else nexty = f->y;
    // }
    // else
    // {
    //     nextx = f->x;
    //     nexty = f->y;
    // }

    int targetx, targety;

    // Decide target: banana OR exit
    pthread_mutex_lock(&f->stats_mutex);
    int exiting = f->going_to_exit;
    pthread_mutex_unlock(&f->stats_mutex);

    if (exiting) {
        targetx = G.exit_x[f->family_id];
        targety = G.exit_y[f->family_id];
    } else {
        if (!maze_find_nearest_banana(f->x, f->y, &targetx, &targety)) {
            targetx = f->x;
            targety = f->y;
        }
    }

    // Compute step toward target
    if (targetx > f->x) nextx = f->x + 1;
    else if (targetx < f->x) nextx = f->x - 1;
    else nextx = f->x;

    if (targety > f->y) nexty = f->y + 1;
    else if (targety < f->y) nexty = f->y - 1;
    else nexty = f->y;


    maze_clamp(&nextx, &nexty);

    // obstacle avoidance (same as you had)
    if (maze[nexty][nextx].obstacle)
    {
        int tryx = f->x, tryy = f->y;

        if (targetx > f->x)      tryx = f->x + 1;
        else if (targetx < f->x) tryx = f->x - 1;
        maze_clamp(&tryx, &tryy);

        if (!maze[tryy][tryx].obstacle) {
            nextx = tryx; nexty = tryy;
        } else {
            tryx = f->x; tryy = f->y;

            if (targety > f->y)      tryy = f->y + 1;
            else if (targety < f->y) tryy = f->y - 1;
            maze_clamp(&tryx, &tryy);

            if (!maze[tryy][tryx].obstacle) {
                nextx = tryx; nexty = tryy;
            } else {
                nextx = f->x; nexty = f->y;
            }
        }
    }

    // -----------------------------
    // 2) Lock old+new cells in global order
    // -----------------------------
    int oldx = f->x, oldy = f->y;
    int id_old = maze_cell_id(oldx, oldy);
    int id_new = maze_cell_id(nextx, nexty);

    if (id_old < id_new) {
        maze_lock(oldx, oldy);
        if (id_old != id_new) maze_lock(nextx, nexty);
    } else if (id_new < id_old) {
        maze_lock(nextx, nexty);
        maze_lock(oldx, oldy);
    } else {
        maze_lock(oldx, oldy);
    }

    // -----------------------------
    // 3) Check occupancy
    // -----------------------------
    int opponent_id = (id_old == id_new) ? -1 : maze[nexty][nextx].occupant;

    // If occupied by another female -> fight decision happens AFTER unlocking cells
    int fight_happened = 0;
    int i_win = 0;

    if (opponent_id != -1 && opponent_id != f->id)
    {
        // release cell locks before locking stats (avoid deadlock)
        if (id_old != id_new) {
            if (id_old < id_new) { maze_unlock(nextx, nexty); maze_unlock(oldx, oldy); }
            else                 { maze_unlock(oldx, oldy);   maze_unlock(nextx, nexty); }
        } else {
            maze_unlock(oldx, oldy);
        }

        // ---- fight (lock both females in id order) ----
        FemaleApe *opp = &females[opponent_id];
        FemaleApe *first  = (f->id < opp->id) ? f : opp;
        FemaleApe *second = (f->id < opp->id) ? opp : f;

        pthread_mutex_lock(&first->stats_mutex);
        pthread_mutex_lock(&second->stats_mutex);

        int power_me  = f->energy + f->bananas;
        int power_opp = opp->energy + opp->bananas;

        i_win = (power_me >= power_opp);

        if (i_win) {
            // winner takes bananas
            f->bananas += opp->bananas;
            opp->bananas = 0;

            female_drain_energy(f,  FIGHT_WIN_COST);
            female_drain_energy(opp, FIGHT_LOSE_COST);
        } else {
            opp->bananas += f->bananas;
            f->bananas = 0;

            female_drain_energy(opp, FIGHT_WIN_COST);
            female_drain_energy(f,  FIGHT_LOSE_COST);
        }

        pthread_mutex_unlock(&second->stats_mutex);
        pthread_mutex_unlock(&first->stats_mutex);

        fight_happened = 1;

        // After fight: only move if I won
        if (!i_win) {
            // I lost -> stay in place and end this step
            if (count_remaining_bananas() == 0)
                atomic_store(&G.any_family_reached_basket_threshold, 1);
            return;
        }

        // I won -> try to move into the cell now (need to re-lock cells)
        // re-lock old+new cells in global order again
        if (id_old < id_new) {
            maze_lock(oldx, oldy);
            maze_lock(nextx, nexty);
        } else {
            maze_lock(nextx, nexty);
            maze_lock(oldx, oldy);
        }

        // If opponent already moved away, we still can move in safely
        // because occupancy is checked/updated under lock below.
    }

    // -----------------------------
    // 4) If target occupied (still) by someone else -> stay
    // -----------------------------
    if (id_old != id_new) {
        int occ = maze[nexty][nextx].occupant;
        if (occ != -1 && occ != f->id) {
            // cannot enter; stay
            nextx = oldx;
            nexty = oldy;
        }
    }

    // -----------------------------
    // 5) Update occupancy and position
    // -----------------------------
    if (nextx != oldx || nexty != oldy) {
        maze[oldy][oldx].occupant = -1;
        maze[nexty][nextx].occupant = f->id;
        f->x = nextx;
        f->y = nexty;
    }

    // -----------------------------
    // 5.5) If reached exit cell, deposit under male protection
    // -----------------------------
    if (f->going_to_exit &&
        f->x == G.exit_x[f->family_id] &&
        f->y == G.exit_y[f->family_id])
    {
        // Unlock maze cells BEFORE waiting on basket gate (avoid deadlock)
        if (id_old != id_new) {
            if (id_old < id_new) {
                maze_unlock(nextx, nexty);
                maze_unlock(oldx, oldy);
            } else {
                maze_unlock(oldx, oldy);
                maze_unlock(nextx, nexty);
            }
        } else {
            maze_unlock(oldx, oldy);
        }

        female_request_deposit(f);   // blocks on G.basket_gate[family_id]
        return;
    }


    // -----------------------------
    // 6) Collect bananas under cell lock
    // -----------------------------

    pthread_mutex_lock(&f->stats_mutex);
    int exiting_now = f->going_to_exit;
    pthread_mutex_unlock(&f->stats_mutex);

    if (!exiting_now)
    {
        int taken = maze_take_bananas(nextx, nexty, COLLECT_LIMIT);

        pthread_mutex_lock(&f->stats_mutex);
        f->bananas += taken;
        female_drain_energy(f, MOVE_COST + (taken > 0 ? COLLECT_COST : 0));

        if (f->bananas >= EXIT_LIMIT)
            f->going_to_exit = 1;

        pthread_mutex_unlock(&f->stats_mutex);
    }
    else
    {
        // exiting: do NOT collect bananas, only pay move energy
        pthread_mutex_lock(&f->stats_mutex);
        female_drain_energy(f, MOVE_COST);
        pthread_mutex_unlock(&f->stats_mutex);
    }


    // -----------------------------
    // 7) Unlock cells
    // -----------------------------
    if (id_old != id_new) {
        if (id_old < id_new) {
            maze_unlock(nextx, nexty);
            maze_unlock(oldx, oldy);
        } else {
            maze_unlock(oldx, oldy);
            maze_unlock(nextx, nexty);
        }
    } else {
        maze_unlock(oldx, oldy);
    }

    // End simulation if maze empty
    if (count_remaining_bananas() == 0)
        atomic_store(&G.any_family_reached_basket_threshold, 1);


    (void)fight_happened; // for debugging if you want to print later
}

void female_fight(FemaleApe *a, FemaleApe *b)
{
    FemaleApe *first = (a->id < b->id) ? a : b;
    FemaleApe *second = (a->id < b->id) ? b : a;

    // pthread_mutex_lock(&fight_mutex);
    pthread_mutex_lock(&first->stats_mutex);
    pthread_mutex_lock(&second->stats_mutex);

    int powerA = a->energy + a->bananas;
    int powerB = b->energy + b->bananas;

    if(powerA >= powerB) {      // A wins
        a->bananas += b->bananas;
        b->bananas = 0;

	    female_drain_energy(a, FIGHT_WIN_COST);
	    female_drain_energy(b, FIGHT_LOSE_COST); // loser loses more energy
    }
    else {                       // B wins
        b->bananas += a->bananas;
        a->bananas = 0;
	
	    female_drain_energy(b, FIGHT_WIN_COST);
	    female_drain_energy(a, FIGHT_LOSE_COST);
    }

    // pthread_mutex_unlock(&fight_mutex);
    pthread_mutex_unlock(&second->stats_mutex);
    pthread_mutex_unlock(&first->stats_mutex);
}

// NOTE: Caller must hold f->stats_mutex before calling this function.
void female_drain_energy(FemaleApe *f, int cost)
{
    if (f->energy > 0)
        f->energy -= cost;

    if (f->energy < 0)
        f->energy = 0;
}

void female_request_deposit(FemaleApe *f)
{
    pthread_mutex_lock(&G.basket_gate[f->family_id]);   // wait for male protection

    pthread_mutex_lock(&f->stats_mutex);
    int amount = f->bananas;
    f->bananas = 0;
    f->going_to_exit = 0;
    pthread_mutex_unlock(&f->stats_mutex);

    basket_deposit(f->family_id, amount);

    pthread_mutex_unlock(&G.basket_gate[f->family_id]);

    // Return to maze entrance
    // Re-enter from family entrance (same as initial spawn)
    f->x = 1 + (f->id % 3);
    f->y = 1 + (f->id / 3);

    maze_clamp(&f->x, &f->y);

    // Register occupancy safely
    int attempts = 0;

    while (attempts < MAZE_W * MAZE_H)
    {
        maze_lock(f->x, f->y);

        // free + not obstacle?
        if (!maze[f->y][f->x].obstacle && maze[f->y][f->x].occupant == -1)
        {
            maze[f->y][f->x].occupant = f->id;
            maze_unlock(f->x, f->y);
            break;
        }

        maze_unlock(f->x, f->y);

        // try next cell (scan pattern)
        f->x++;
        if (f->x >= MAZE_W) {
            f->x = 0;
            f->y = (f->y + 1) % MAZE_H;
        }

        attempts++;
    }
}


