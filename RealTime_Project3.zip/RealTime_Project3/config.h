#ifndef CONFIG_H
#define CONFIG_H

typedef struct {
    /* Female */
    int num_females;
    int female_max_energy;
    int rest_threshold;
    int rest_time;

    int move_cost;
    int collect_cost;
    int collect_limit;
    int exit_limit;

    int fight_win_cost;
    int fight_lose_cost;

    /* Maze */
    int maze_w;
    int maze_h;
    int obstacle_percent;
    int max_bananas_cell;

    /* Male / Baby */
    int num_males;
    int babies_per_family;

    int male_energy_init;
    int male_energy_min_withdraw;
    int male_energy_fight_cost;

    int basket_win_threshold;
    int withdrawn_families_threshold;

    int baby_eat_threshold;
    int baby_steal_max_each_try;

    int fight_check_ms;
    int monitor_check_ms;
    int render_ms;
    int time_limit_sec;

    double fight_p_base;
    double fight_alpha;
    double fight_p_max;
} Config;

int load_config(const char *path, Config *cfg);

#endif

