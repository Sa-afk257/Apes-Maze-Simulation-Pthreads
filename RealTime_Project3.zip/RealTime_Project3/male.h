#ifndef MALE_H
#define MALE_H

void *male_thread(void *arg);
void lock_two_baskets(int a, int b);
void unlock_two_baskets(int a, int b);
double fight_probability(int basket_count) ;
void do_male_fight(int me, int nb);
int basket_get(int id);
void basket_deposit(int id, int amount);
			
			
#endif
