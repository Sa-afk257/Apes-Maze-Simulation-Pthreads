#ifndef SYNC_H
#define SYNC_H
#include <stdatomic.h>
#include <pthread.h>

/* ---- TIME LIMIT control ---- */
extern atomic_int time_up;
extern int TIME_LIMIT;


extern atomic_int bananas_done;

/* ---- Global simulation control ---- */
extern atomic_int simulation_running;

/* ---- Fight synchronization ---- */
extern pthread_mutex_t fight_mutex;

/* ---- Withdrawn families counter ---- */
extern int withdrawn_count;
extern pthread_mutex_t withdrawn_mutex;
void increment_withdrawn(void);

/* ---- User-defined parameters (from config.txt) ---- */
extern int REST_THRESHOLD;
extern int REST_TIME;
extern int MAX_ENERGY;
extern int MOVE_COST;
extern int COLLECT_COST;
extern int FIGHT_WIN_COST;
extern int FIGHT_LOSE_COST;
extern int EXIT_LIMIT;
extern int COLLECT_LIMIT;
extern int MALE_MIN_ENERGY;
extern int NUM_FEMALES;

/* male_energy[] is defined in basket.c */
extern int *male_energy;

#endif
