#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <stdatomic.h>
#include <time.h>

#include "shared_state.h"
#include "config.h"
#include "sync.h"

#include "male.h"
#include "baby.h"
#include "monitor.h"
#include "render.h"

#include "female.h"
#include "maze.h"

// ---------------- Timer Thread ----------------
static void *timer_thread(void *arg)
{
    int seconds = *(int *)arg;
    sleep(seconds);

    atomic_store(&G.simulation_running, 0);
    printf("[INFO] Time limit reached — stopping simulation.\n");
    return NULL;
}

int main(int argc, char **argv)
{

  srand(time(NULL));
    const char *cfgPath = (argc >= 2) ? argv[1] : "config.txt";

    // 1) Load config
    Config cfg;
    if (load_config(cfgPath, &cfg) != 0) {
        printf("Could not open config file '%s'. Exiting.\n", cfgPath);
        return 1;
    }

    // 2) Init shared state
    if (shared_init(&cfg) != 0) {
        printf("shared_init failed\n");
        return 1;
    }

    // 3) Init maze
    maze_init(cfg.maze_w, cfg.maze_h, cfg.obstacle_percent, cfg.max_bananas_cell);

    // 4) Start timer
    pthread_t timer;
    int time_limit = cfg.time_limit_sec;
    pthread_create(&timer, NULL, timer_thread, &time_limit);

    // 5) Start monitor (thread)
    pthread_t mon;
    pthread_create(&mon, NULL, monitor_thread, NULL);

    // 6) Create male threads
    pthread_t *maleT = calloc((size_t)cfg.num_males, sizeof(pthread_t));
    int *maleId = calloc((size_t)cfg.num_males, sizeof(int));
    if (!maleT || !maleId) {
        perror("calloc male");
        return 1;
    }

    for (int i = 0; i < cfg.num_males; i++) {
        maleId[i] = i;
        pthread_create(&maleT[i], NULL, male_thread, &maleId[i]);
    }

    // 7) Create female threads  (IMPORTANT: allocate females BEFORE render starts)
    int num_females = cfg.num_females;
    females = calloc((size_t)num_females, sizeof(FemaleApe));
    pthread_t *femaleT = calloc((size_t)num_females, sizeof(pthread_t));
    if (!females || !femaleT) {
        perror("calloc female");
        return 1;
    }

    for (int i = 0; i < num_females; i++) {
        female_init(&females[i], i);
        pthread_create(&femaleT[i], NULL, female_thread, &females[i]);
    }

    // 8) Create baby threads
    pthread_t *babyT = calloc((size_t)G.total_babies, sizeof(pthread_t));
    int *babyId = calloc((size_t)G.total_babies, sizeof(int));
    if (!babyT || !babyId) {
        perror("calloc baby");
        return 1;
    }

    for (int i = 0; i < G.total_babies; i++) {
        babyId[i] = i;
        pthread_create(&babyT[i], NULL, baby_thread, &babyId[i]);
    }
    render_thread(NULL);
  

    // ==========================================================
    // IMPORTANT: OpenGL/GLUT MUST run in MAIN thread.
    // Put it at the END (it blocks forever in glutMainLoop).
    // Your render_thread() already exits when simulation_running == 0.
    // ==========================================================
    // render_thread(NULL);

    // NOTE: Code below typically won't run if render_thread uses exit(0).
    // If you later switch to glutLeaveMainLoop(), these joins will work.

    pthread_join(timer, NULL);
    pthread_join(mon, NULL);

    for (int i = 0; i < num_females; i++) pthread_join(femaleT[i], NULL);
    for (int i = 0; i < cfg.num_males; i++) pthread_join(maleT[i], NULL);
    for (int i = 0; i < G.total_babies; i++) pthread_join(babyT[i], NULL);

    // Cleanup
    for (int i = 0; i < num_females; i++)
        pthread_mutex_destroy(&females[i].stats_mutex);

    free(femaleT);
    free(females);
    free(maleT);
    free(maleId);
    free(babyT);
    free(babyId);

    maze_destroy();
    shared_cleanup();

    printf("\n[INFO] Simulation finished. Press Enter to exit...\n");
    getchar();
    return 0;
}
