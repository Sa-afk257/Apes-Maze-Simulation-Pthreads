#ifndef FEMALE_H
#define FEMALE_H

#include <pthread.h>
#include <stdatomic.h>

/* Female Ape structure */
typedef struct
{
    int id;          /* family / female id */
    int x, y;        /* current maze position */
    int energy;      /* current energy */
    int bananas;     /* bananas currently carried */
    int withdrawn;   /* 1 = family withdrew */
    int resting;     /* 1 = currently resting */
    pthread_mutex_t stats_mutex;   // NEW: protects energy & bananas
    int going_to_exit;          // 1 = heading to exit to deposit bananas 
    int family_id;              // which male/family she belongs to
} FemaleApe;


/* Dynamically allocated global females array */
extern FemaleApe *females;

/* Thread entry */
void *female_thread(void *arg);
/* Female logic */
void female_init(FemaleApe *f, int id);
void female_rest(FemaleApe *f);
void female_move(FemaleApe *f);
void female_fight(FemaleApe *a, FemaleApe *b);
void female_drain_energy(FemaleApe *f, int cost);
void female_request_deposit(FemaleApe *f);

#endif
