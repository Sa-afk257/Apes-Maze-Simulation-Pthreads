#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "config.h"

/* Helper: trim leading/trailing whitespace */
static char *trim(char *s)
{
    while (isspace((unsigned char)*s)) s++;
    if (*s == 0) return s;

    char *end = s + strlen(s) - 1;
    while (end > s && isspace((unsigned char)*end)) end--;
    end[1] = '\0';
    return s;
}

/* Set default values (important!) */
static void set_defaults(Config *cfg)
{
    /* -------- Female Apes -------- */
    cfg->num_females        = 6;
    cfg->female_max_energy = 100;
    cfg->rest_threshold    = 25;
    cfg->rest_time         = 2;

    /* Movement & collection */
    cfg->move_cost         = 3;
    cfg->collect_cost      = 2;
    cfg->collect_limit     = 2;
    cfg->exit_limit        = 10;

    /* Female fight */
    cfg->fight_win_cost    = 4;
    cfg->fight_lose_cost   = 8;

    /* Maze */
    cfg->maze_w            = 15;
    cfg->maze_h            = 15;
    cfg->obstacle_percent  = 20;
    cfg->max_bananas_cell  = 4;

    /* -------- Group B (Male/Baby) -------- */
    cfg->num_males                     = 4;
    cfg->babies_per_family             = 2;

    cfg->male_energy_init              = 100;
    cfg->male_energy_min_withdraw      = 20;
    cfg->male_energy_fight_cost        = 10;

    cfg->basket_win_threshold          = 80;
    cfg->withdrawn_families_threshold  = 2;

    cfg->baby_eat_threshold            = 30;
    cfg->baby_steal_max_each_try       = 3;

    cfg->fight_check_ms                = 200;
    cfg->monitor_check_ms              = 100;
    cfg->render_ms                     = 500;
    cfg->time_limit_sec                = 20;

    cfg->fight_p_base                  = 0.02;
    cfg->fight_alpha                   = 0.002;
    cfg->fight_p_max                   = 0.50;
}

/* Load config file */
int load_config(const char *path, Config *cfg)
{
    FILE *fp = fopen(path, "r");
    if (!fp) {
        perror("fopen");
        return -1;
    }

    set_defaults(cfg);

    char line[256];

    while (fgets(line, sizeof(line), fp)) {
        char *p = trim(line);

        /* Skip comments & empty lines */
        if (*p == '#' || *p == '\0')
            continue;

        char *eq = strchr(p, '=');
        if (!eq) continue;

        *eq = '\0';
        char *key = trim(p);
        char *val = trim(eq + 1);

        /* -------- Female -------- */
        if      (!strcmp(key, "NUM_FEMALES"))          cfg->num_females = atoi(val);
        else if (!strcmp(key, "MAX_ENERGY"))           cfg->female_max_energy = atoi(val);
        else if (!strcmp(key, "REST_THRESHOLD"))       cfg->rest_threshold = atoi(val);
        else if (!strcmp(key, "REST_TIME"))            cfg->rest_time = atoi(val);

        else if (!strcmp(key, "MOVE_COST"))             cfg->move_cost = atoi(val);
        else if (!strcmp(key, "COLLECT_COST"))          cfg->collect_cost = atoi(val);
        else if (!strcmp(key, "COLLECT_LIMIT"))         cfg->collect_limit = atoi(val);
        else if (!strcmp(key, "EXIT_LIMIT"))            cfg->exit_limit = atoi(val);

        else if (!strcmp(key, "FIGHT_WIN_COST"))        cfg->fight_win_cost = atoi(val);
        else if (!strcmp(key, "FIGHT_LOSE_COST"))       cfg->fight_lose_cost = atoi(val);

        /* -------- Maze -------- */
        else if (!strcmp(key, "MAZE_W"))                cfg->maze_w = atoi(val);
        else if (!strcmp(key, "MAZE_H"))                cfg->maze_h = atoi(val);
        else if (!strcmp(key, "OBSTACLE_PERCENT"))      cfg->obstacle_percent = atoi(val);
        else if (!strcmp(key, "MAX_BANANAS_PER_CELL"))  cfg->max_bananas_cell = atoi(val);

        /* -------- Group B -------- */
        else if (!strcmp(key, "num_males"))             cfg->num_males = atoi(val);
        else if (!strcmp(key, "babies_per_family"))     cfg->babies_per_family = atoi(val);

        else if (!strcmp(key, "male_energy_init"))         cfg->male_energy_init = atoi(val);
        else if (!strcmp(key, "male_energy_min_withdraw")) cfg->male_energy_min_withdraw = atoi(val);
        else if (!strcmp(key, "male_energy_fight_cost"))   cfg->male_energy_fight_cost = atoi(val);

        else if (!strcmp(key, "basket_win_threshold"))         cfg->basket_win_threshold = atoi(val);
        else if (!strcmp(key, "withdrawn_families_threshold")) cfg->withdrawn_families_threshold = atoi(val);

        else if (!strcmp(key, "baby_eat_threshold"))      cfg->baby_eat_threshold = atoi(val);
        else if (!strcmp(key, "baby_steal_max_each_try")) cfg->baby_steal_max_each_try = atoi(val);

        else if (!strcmp(key, "fight_check_ms"))    cfg->fight_check_ms = atoi(val);
        else if (!strcmp(key, "monitor_check_ms"))  cfg->monitor_check_ms = atoi(val);
        else if (!strcmp(key, "render_ms"))         cfg->render_ms = atoi(val);
        else if (!strcmp(key, "time_limit_sec"))    cfg->time_limit_sec = atoi(val);

        else if (!strcmp(key, "fight_p_base"))       cfg->fight_p_base = atof(val);
        else if (!strcmp(key, "fight_alpha"))        cfg->fight_alpha = atof(val);
        else if (!strcmp(key, "fight_p_max"))        cfg->fight_p_max = atof(val);
    }

    fclose(fp);
    return 0;
}
