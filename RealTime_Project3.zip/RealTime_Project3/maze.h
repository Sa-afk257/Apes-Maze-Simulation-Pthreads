//maze.h
#ifndef MAZE_HEADER_H
#define MAZE_HEADER_H

#include <pthread.h>

// One cell in the maze
typedef struct {
    int obstacle;   // 1 = this cell is blocked, 0 = free
    atomic_int bananas;    // number of bananas in this cell
    int occupant;   // -1 = empty, otherwise female id 
} Cell;

// Global maze size (defined in maze.c)
extern int MAZE_W;           // Maze width
extern int MAZE_H;           // Maze height

// Global maze data (defined in maze.c)
extern Cell **maze;                   // 2D array of cells
extern pthread_mutex_t **maze_mutex;  // 2D array of mutexes (one per cell)
extern int initial_bananas;           // Total bananas at the beginning

// Create and initialize the maze
void maze_init(int W, int H, int obstacles_percent, int max_bananas);

// Free all maze memory and destroy mutexes
void maze_destroy(void);

// Keep (x, y) inside the maze boundaries
void maze_clamp(int *x, int *y);

// Thread-safe function to take bananas from one cell
int maze_take_bananas(int x, int y, int max_take);

// Count all bananas remaining in the maze
int count_remaining_bananas(void);

//lock and unlock a specific cell
void maze_lock(int x, int y);
void maze_unlock(int x, int y);

//find the nearest banana from (sx, sy)
int maze_find_nearest_banana(int sx, int sy, int *bx, int *by);

int maze_cell_id(int x, int y);



#endif // MAZE_HEADER_H
