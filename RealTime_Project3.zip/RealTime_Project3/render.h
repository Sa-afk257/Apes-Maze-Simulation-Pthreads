#ifndef RENDER_H
#define RENDER_H

void *render_thread(void *arg);
void timer_cb(int v);
void keyboard(unsigned char key, int x, int y);
void reshape(int w, int h);
void display(void);
void draw_stats_panel(float left, float right, float bottom, float top);
void draw_maze_panel(float left, float right, float bottom, float top);
void circle(float cx, float cy, float r, int seg);
void rect(float x0, float y0, float x1, float y1);
void take_snapshot(void);
void snapshot_init_if_needed(void);
void save_screenshot_ppm(const char *filename, int w, int h);
void clamp01(float *v);
void draw_text(float x, float y, const char *txt);
void mkdir_if_missing(const char *path);

#endif
