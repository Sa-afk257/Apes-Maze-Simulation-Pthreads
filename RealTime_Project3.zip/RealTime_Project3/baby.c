#include "baby.h"
#include "shared_state.h"
#include <stdio.h>

static int is_dad_in_fight(int dad, const FightEvent *ev) {
    return (ev->maleA == dad || ev->maleB == dad);
}

static int choose_victim(int dad, const FightEvent *ev) {
    // If dad is fighting, victim is the other male in the fight (steal from opponent)
    if (!is_dad_in_fight(dad, ev)) return -1;
    return (ev->maleA == dad) ? ev->maleB : ev->maleA;
}

void *baby_thread(void *arg) {
    int baby_id = *(int*)arg;
    Baby *bb = &G.babies[baby_id];

    while (atomic_load(&G.simulation_running)) {
        FightEvent ev;
        if (fight_event_get(&ev)) {
            // baby acts only if his dad is in the current fight event
            int victim = choose_victim(bb->dad_id, &ev);
            if (victim != -1 && !G.males[victim].withdrawn && !G.males[bb->dad_id].withdrawn) {

                int steal = rand_int(1, G.cfg.baby_steal_max_each_try);

                // Take from victim basket (locked internally by basket_take_all? no, we need partial take)
                // We'll do partial stealing by locking victim basket.
                Male *vm = &G.males[victim];
                pthread_mutex_lock(&vm->basket_mutex);

                int available = vm->basket_bananas;
                int taken = (available >= steal) ? steal : available;
                vm->basket_bananas -= taken;

                pthread_mutex_unlock(&vm->basket_mutex);

                if (taken > 0) {
                    // 50%: eat, 50%: put into dad basket
                    if (rand_int(0, 1) == 0) {
                        bb->eaten_bananas += taken;
                        if (bb->eaten_bananas >= G.cfg.baby_eat_threshold) {
                            atomic_store(&G.any_baby_reached_eat_threshold, 1);
                        }
                    } else {
                        basket_add(bb->dad_id, taken);
                    }
                }
            }
        }

        // small sleep to avoid busy waiting
        ms_sleep(50);
    }
    return NULL;
}
