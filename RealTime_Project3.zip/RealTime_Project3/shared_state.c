#include "shared_state.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

SharedState G;

uint64_t now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000ULL + (uint64_t)(ts.tv_nsec / 1000000ULL);
}

void ms_sleep(int ms) {
    if (ms <= 0) return;
    usleep((useconds_t)ms * 1000);
}

// Simple thread-safe RNG using rand_r + TLS seed
static _Thread_local unsigned int tls_seed = 0;

static void ensure_seed(void) {
    if (tls_seed == 0) {
        tls_seed = (unsigned int)time(NULL) ^ (unsigned int)(uintptr_t)pthread_self();
        if (tls_seed == 0) tls_seed = 1234567;
    }
}

int rand_int(int lo, int hi) {
    ensure_seed();
    if (hi < lo) { int t = lo; lo = hi; hi = t; }
    unsigned int r = rand_r(&tls_seed);
    int span = hi - lo + 1;
    return lo + (int)(r % (unsigned int)span);
}

double rand_double_0_1(void) {
    ensure_seed();
    unsigned int r = rand_r(&tls_seed);
    return (double)r / (double)UINT32_MAX;
}

int shared_init(const Config *cfg) {
    G.cfg = *cfg;

    atomic_store(&G.withdrawn_families_count, 0);
    atomic_store(&G.simulation_running, 1);
    atomic_store(&G.any_family_reached_basket_threshold, 0);
    atomic_store(&G.any_baby_reached_eat_threshold, 0);

    pthread_mutex_init(&G.stop_mutex, NULL);
    pthread_cond_init(&G.stop_cv, NULL);

    pthread_mutex_init(&G.fight_event_mutex, NULL);
    G.fight_event.active = 0;
    G.fight_event.maleA = -1;
    G.fight_event.maleB = -1;
    G.fight_event.until_ms = 0;

    G.males = calloc((size_t)cfg->num_males, sizeof(Male));
    if (!G.males) return -1;

    // ================= BASKET EXIT + MALE GATE =================
    G.basket_gate = calloc((size_t)cfg->num_males, sizeof(pthread_mutex_t));
    G.exit_x      = calloc((size_t)cfg->num_males, sizeof(int));
    G.exit_y      = calloc((size_t)cfg->num_males, sizeof(int));

    if (!G.basket_gate || !G.exit_x || !G.exit_y) return -1;

    for (int i = 0; i < cfg->num_males; i++) {
        pthread_mutex_init(&G.basket_gate[i], NULL);

        // fixed exit position per family (safe + visible)
        G.exit_x[i] = 0;
        G.exit_y[i] = i % cfg->maze_h;
    }
    // ==========================================================


    G.total_babies = cfg->num_males * cfg->babies_per_family;
    G.babies = calloc((size_t)G.total_babies, sizeof(Baby));
    if (!G.babies) return -1;

    for (int i = 0; i < cfg->num_males; i++) {
        G.males[i].id = i;
        G.males[i].energy = cfg->male_energy_init;
        G.males[i].withdrawn = 0;
        G.males[i].basket_bananas = 0;
        pthread_mutex_init(&G.males[i].basket_mutex, NULL);
    }

    int b = 0;
    for (int dad = 0; dad < cfg->num_males; dad++) {
        for (int k = 0; k < cfg->babies_per_family; k++) {
            G.babies[b].id = b;
            G.babies[b].dad_id = dad;
            G.babies[b].eaten_bananas = 0;
            b++;
        }
    }

    G.start_ms = now_ms();
    return 0;
}

void shared_cleanup(void)
{
    if (G.males) {
        for (int i = 0; i < G.cfg.num_males; i++) {
            pthread_mutex_destroy(&G.males[i].basket_mutex);

            if (G.basket_gate)
                pthread_mutex_destroy(&G.basket_gate[i]);
        }
        free(G.males);
        G.males = NULL;
    }

    if (G.basket_gate) {
        free(G.basket_gate);
        G.basket_gate = NULL;
    }

    if (G.exit_x) {
        free(G.exit_x);
        G.exit_x = NULL;
    }

    if (G.exit_y) {
        free(G.exit_y);
        G.exit_y = NULL;
    }

    if (G.babies) {
        free(G.babies);
        G.babies = NULL;
    }

    pthread_mutex_destroy(&G.fight_event_mutex);
    pthread_mutex_destroy(&G.stop_mutex);
    pthread_cond_destroy(&G.stop_cv);
}


void basket_add(int male_id, int amount) {
    if (amount <= 0) return;
    Male *m = &G.males[male_id];
    pthread_mutex_lock(&m->basket_mutex);
    m->basket_bananas += amount;
    int total = m->basket_bananas;
    pthread_mutex_unlock(&m->basket_mutex);

    if (total >= G.cfg.basket_win_threshold) {
        atomic_store(&G.any_family_reached_basket_threshold, 1);
    }
}

int basket_take_all(int male_id) {
    Male *m = &G.males[male_id];
    pthread_mutex_lock(&m->basket_mutex);
    int taken = m->basket_bananas;
    m->basket_bananas = 0;
    pthread_mutex_unlock(&m->basket_mutex);
    return taken;
}

int basket_get(int male_id) {
    Male *m = &G.males[male_id];
    pthread_mutex_lock(&m->basket_mutex);
    int val = m->basket_bananas;
    pthread_mutex_unlock(&m->basket_mutex);
    return val;
}

void fight_event_set(int a, int b, int duration_ms) {
    pthread_mutex_lock(&G.fight_event_mutex);
    G.fight_event.active = 1;
    G.fight_event.maleA = a;
    G.fight_event.maleB = b;
    G.fight_event.until_ms = now_ms() + (uint64_t)duration_ms;
    pthread_mutex_unlock(&G.fight_event_mutex);
}

int fight_event_get(FightEvent *out) {
    int ok = 0;
    pthread_mutex_lock(&G.fight_event_mutex);
    if (G.fight_event.active) {
        // expire
        if (now_ms() >= G.fight_event.until_ms) {
            G.fight_event.active = 0;
        }
    }
    if (G.fight_event.active) {
        *out = G.fight_event;
        ok = 1;
    }
    pthread_mutex_unlock(&G.fight_event_mutex);
    return ok;
}

void request_stop(void) {
    // set running=0 once
    atomic_store(&G.simulation_running, 0);
    pthread_mutex_lock(&G.stop_mutex);
    pthread_cond_broadcast(&G.stop_cv);
    pthread_mutex_unlock(&G.stop_mutex);
}
