#include "male.h"
#include "shared_state.h"
#include <stdio.h>
#include <pthread.h>
#include <stdatomic.h>

// lock two baskets in a fixed order to avoid deadlock
 void lock_two_baskets(int a, int b) {
    if (a == b) {
        pthread_mutex_lock(&G.males[a].basket_mutex);
        return;
    }
    int first = (a < b) ? a : b;
    int second = (a < b) ? b : a;
    pthread_mutex_lock(&G.males[first].basket_mutex);
    pthread_mutex_lock(&G.males[second].basket_mutex);
}
 void unlock_two_baskets(int a, int b) {
    if (a == b) {
        pthread_mutex_unlock(&G.males[a].basket_mutex);
        return;
    }
    int first = (a < b) ? a : b;
    int second = (a < b) ? b : a;
    pthread_mutex_unlock(&G.males[second].basket_mutex);
    pthread_mutex_unlock(&G.males[first].basket_mutex);
}

 double fight_probability(int basket_count) {
    double p = G.cfg.fight_p_base + G.cfg.fight_alpha * (double)basket_count;
    if (p > G.cfg.fight_p_max) p = G.cfg.fight_p_max;
    if (p < 0.0) p = 0.0;
    return p;
}

 void do_male_fight(int me, int nb) {
    // if someone withdrawn => skip
    if (G.males[me].withdrawn || G.males[nb].withdrawn) return;

    // lock both baskets (safe order)
    lock_two_baskets(me, nb);

    int myB = G.males[me].basket_bananas;
    int nbB = G.males[nb].basket_bananas;

    // choose winner: simple random (you can bias by energy later)
    int winner = (rand_int(0, 1) == 0) ? me : nb;
    int loser  = (winner == me) ? nb : me;

    int stolen = G.males[loser].basket_bananas;
    G.males[loser].basket_bananas = 0;
    G.males[winner].basket_bananas += stolen;

    unlock_two_baskets(me, nb);

    // register fight event for babies to steal during it
    fight_event_set(me, nb, 500); // 500ms fight window

    // energy cost
    G.males[me].energy -= G.cfg.male_energy_fight_cost;
    G.males[nb].energy -= G.cfg.male_energy_fight_cost;

    // threshold flags
    if (basket_get(winner) >= G.cfg.basket_win_threshold)
        atomic_store(&G.any_family_reached_basket_threshold, 1);

    (void)myB; (void)nbB;
}

void *male_thread(void *arg) {
    int me = *(int*)arg;

    while (atomic_load(&G.simulation_running)) {
        if (G.males[me].withdrawn) break;

        // Withdrawal check
        if (G.males[me].energy <= G.cfg.male_energy_min_withdraw) {
            G.males[me].withdrawn = 1;
            atomic_fetch_add(&G.withdrawn_families_count, 1);
            break;
        }

        // Try fight with neighbor (left/right)
        int left = me - 1;
        int right = me + 1;

        // choose neighbor randomly among available ones
        int nb = -1;
        if (left >= 0 && right < G.cfg.num_males) nb = (rand_int(0, 1) == 0) ? left : right;
        else if (left >= 0) nb = left;
        else if (right < G.cfg.num_males) nb = right;

        if (nb != -1 && !G.males[nb].withdrawn) {
            int basket_now = basket_get(me);
            double p = fight_probability(basket_now);

            if (rand_double_0_1() < p) {
                do_male_fight(me, nb);
            }
        }

        ms_sleep(G.cfg.fight_check_ms);
    }

    return NULL;
}



void basket_deposit(int id, int amount)
{
    if (amount <= 0) return;

    pthread_mutex_lock(&G.males[id].basket_mutex);

    G.males[id].basket_bananas += amount;                 // deposit safely
    G.males[id].energy -= G.cfg.male_energy_fight_cost; // tired from protecting

    pthread_mutex_unlock(&G.males[id].basket_mutex);

    // optional: stop condition if family reached basket threshold
    if (basket_get(id) >= G.cfg.basket_win_threshold)
        atomic_store(&G.any_family_reached_basket_threshold, 1);
}

/*int basket_get(int id)
{
    pthread_mutex_lock(&G.males[id].basket_mutex);
    int v = G.males[id].basket_bananas;
    pthread_mutex_unlock(&G.males[id].basket_mutex);
    return v;
    }*/
